import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../../lib/auth'

const JSON_BASE = process.env.JSON_API_BASE || 'http://localhost:3001'

function isAllowed(email) {
  const allowed = (process.env.ALLOWED_ADMINS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean)
  return allowed.includes((email || '').toLowerCase())
}

export async function POST(request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const email = session.user?.email
  if (!isAllowed(email)) {
    return NextResponse.json({ error: 'Forbidden: not an admin' }, { status: 403 })
  }

  const body = await request.json()
  const res = await fetch(`${JSON_BASE}/passengers`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })
  const data = await res.json()
  if (!res.ok) return NextResponse.json({ error: 'Upstream failed' }, { status: 502 })
  return NextResponse.json(data, { status: 201 })
}

export async function DELETE(request) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const email = session.user?.email
  if (!isAllowed(email)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  // Implement delete logic if needed in future
  return NextResponse.json({ ok: true })
}
