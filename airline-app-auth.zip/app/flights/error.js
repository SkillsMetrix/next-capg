'use client'
export default function FlightsError({error}){return <div>Error: {String(error)}</div>}