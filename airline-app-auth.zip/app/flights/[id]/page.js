import { fetchFlightById, fetchPassengersByFlightId } from '../../../lib/api'
import PassengerCard from '../../../components/PassengerCard'

export default async function FlightDetails({ params }) {
  const { id } = params
  const flight = await fetchFlightById(id)
  const passengers = await fetchPassengersByFlightId(id)

  return (
    <div>
      <h2>{flight.code} Details</h2>
      <div className="card">
        <div><strong>{flight.from} → {flight.to}</strong></div>
        <div className="small">Duration: {flight.duration} • Seats: {flight.seats}</div>
        <div className="small">Price: ₹{flight.price} • Status: {flight.status}</div>
      </div>

      <h3>Passengers on this flight</h3>
      <div className="grid">
        {passengers.length ? passengers.map(p => <PassengerCard key={p.id} passenger={p} />) : <div className="card">No passengers yet</div>}
      </div>
    </div>
  )
}
