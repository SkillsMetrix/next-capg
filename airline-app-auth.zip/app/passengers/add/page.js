'use client'
import AddPassengerForm from '../../../components/AddPassengerForm'

export default function AddPassengerPage() {
  return (
    <div>
      <h2>Add Passenger</h2>
      <AddPassengerForm />
    </div>
  )
}
