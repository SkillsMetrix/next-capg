import { fetchPassengers } from '../../lib/api'
import PassengerCard from '../../components/PassengerCard'

export default async function PassengersPage() {
  const passengers = await fetchPassengers()
  return (
    <div>
      <h2>Passengers</h2>
      <div className="grid">
        {passengers.map(p => <PassengerCard key={p.id} passenger={p} />)}
      </div>
    </div>
  )
}
