// app/layout.js (snippet)
import './globals.css'
import Link from 'next/link'
import Providers from '../components/Providers'
import AuthStatus from '../components/AuthStatus'
import ConditionalLinks from '../components/ConditionalLinks' // NEW

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        <Providers>
          <div className="container">
            <header className="header" style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
              <div style={{display:'flex', alignItems:'center', gap:12}}>
                <h1>Airline Booking</h1>
                <nav className="nav">
                  <Link href="/">Home</Link>
                  <Link href="/flights">Flights</Link>
                  <Link href="/passengers">Passengers</Link>
                  <Link href="/passengers/add">Add Passenger</Link>
                  {/* conditional links rendered by client component */}
                  <ConditionalLinks />
                </nav>
              </div>

              <div>
                <AuthStatus />
              </div>
            </header>

            <main>{children}</main>
          </div>
        </Providers>
      </body>
    </html>
  )
}
