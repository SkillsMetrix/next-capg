// components/Providers.jsx
'use client'

import { SessionProvider } from 'next-auth/react'

export default function Providers({ children }) {
  // No `session` prop required for standard client usage.
  // Session will be fetched client-side by next-auth.
  return <SessionProvider>{children}</SessionProvider>
}
