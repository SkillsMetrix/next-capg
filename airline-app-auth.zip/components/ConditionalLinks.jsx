// components/ConditionalLinks.jsx
'use client'

import Link from 'next/link'
import { useSession } from 'next-auth/react'

export default function ConditionalLinks() {
  const { data: session, status } = useSession()

  // while loading, show nothing (or a tiny placeholder if you prefer)
  if (status === 'loading') return null

  // if not signed in, render nothing
  if (!session) return null

  // signed in -> show additional links
  return (
    <>
      <Link href="/frequent-flyer">Frequent Flyer</Link>
      <Link href="/member">Member</Link>
    </>
  )
}
