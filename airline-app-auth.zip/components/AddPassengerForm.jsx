'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useSession, signIn } from 'next-auth/react'

export default function AddPassengerForm({ defaultFlightId = '' }) {
  const { data: session, status } = useSession()
  const [name, setName] = useState('')
  const [age, setAge] = useState('')
  const [flightId, setFlightId] = useState(defaultFlightId)
  const [saving, setSaving] = useState(false)
  const router = useRouter()

  if (status === 'loading') {
    return <div className="card">Checking authentication…</div>
  }

  if (!session) {
    return (
      <div className="card">
        <h3>Sign in required</h3>
        <p className="small">You must sign in to add a passenger.</p>
        <div style={{ marginTop: 8 }}>
          <button onClick={() => signIn()}>Sign in</button>
        </div>
      </div>
    )
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    try {
      const res = await fetch('/api/passengers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, age: Number(age), flightId: Number(flightId) })
      })
      if (res.status === 401) {
        alert('Unauthorized — please sign in again.')
        signIn()
        return
      }
      if (res.status === 403) {
        alert('Forbidden — your account is not allowed to add passengers.')
        return
      }
      if (!res.ok) throw new Error('Failed to add')
      router.push('/passengers')
    } catch (err) {
      alert('Error: ' + err.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="card">
      <h3>Add Passenger</h3>
      <div style={{ display: 'grid', gap: 8 }}>
        <input value={name} onChange={e => setName(e.target.value)} placeholder="Full name" required />
        <input value={age} onChange={e => setAge(e.target.value)} placeholder="Age" type="number" required />
        <input value={flightId} onChange={e => setFlightId(e.target.value)} placeholder="Flight ID" required />
        <button disabled={saving} type="submit">{saving ? 'Saving...' : 'Add Passenger'}</button>
      </div>
    </form>
  )
}
