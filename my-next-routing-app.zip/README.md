# my-next-app
Example Next.js app demonstrating:
- App Router with route groups
- Root + group layouts
- Static, Nested, Dynamic, and Catch-all routes
- Navigation component with labels

How to run:
1. Install dependencies:
   npm install
2. Start dev server:
   npm run dev
3. Open http://localhost:3000

Project layout:
- app/(site) -> public site pages (Home, About, Services, Blog, Docs)
- app/(dashboard) -> dashboard group with sidebar (Dashboard, Settings, Reports)
- components/Navigation.* -> shared navigation used in site layout
