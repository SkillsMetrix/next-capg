export default function DashboardSettings() { return <h1>⚙️ Dashboard Settings</h1>; }
