export default function ReportsPage() {
  return (
    <div>
      <h1>📈 Reports</h1>
      <p>This page lives under the <strong>(dashboard)</strong> route group and shares the dashboard layout.</p>

      <section>
        <h2>Available Reports</h2>
        <ul>
          <li>Sales Overview</li>
          <li>User Activity</li>
          <li>System Health</li>
        </ul>
      </section>
    </div>
  );
}
