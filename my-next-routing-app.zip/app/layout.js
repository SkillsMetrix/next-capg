import "./globals.css";

export const metadata = {
  title: "My Next App",
  description: "App with Route Groups",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head />
      <body>
        {children}
      </body>
    </html>
  );
}
