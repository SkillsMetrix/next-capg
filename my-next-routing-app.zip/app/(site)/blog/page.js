import Link from "next/link";

const POSTS = [
  { title: "Next.js Routing Essentials", slug: "nextjs-routing" },
  { title: "React vs Next.js", slug: "react-vs-next" },
  { title: "How to Deploy", slug: "how-to-deploy" },
];

export default function BlogIndex() {
  return (
    <div>
      <h1>📝 Blog</h1>
      <ul>
        {POSTS.map(p => (
          <li key={p.slug}>
            <Link href={`/blog/${p.slug}`}>{p.title} — <small>/{p.slug}</small></Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
