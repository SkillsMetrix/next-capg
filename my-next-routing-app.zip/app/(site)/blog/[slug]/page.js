export default function BlogPost({ params }) {
  const { slug } = params;
  return (
    <article>
      <h1>Blog Post: {slug}</h1>
      <p>Dynamic route example (params.slug).</p>
    </article>
  );
}
