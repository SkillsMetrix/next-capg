export default function WebService() { return <h1>🌐 Web Development Services (Static nested: /services/web)</h1>; }
