export default function Services() { return <h1>💼 Services (Static)</h1>; }
