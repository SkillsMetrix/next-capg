export default function MobileService() { return <h1>📱 Mobile Apps (Static nested: /services/mobile)</h1>; }
