/** Next.js config placeholder */
module.exports = { reactStrictMode: true };
