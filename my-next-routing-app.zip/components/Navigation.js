"use client";

import Link from "next/link";
import styles from "./Navigation.module.css";

export default function Navigation() {
  return (
    <nav className={styles.navBar} aria-label="Main navigation">
      <ul className={styles.navList}>

        <li className={styles.navItem}>
          <Link href="/" className={styles.link}>Home (Static: /)</Link>
        </li>

        <li className={styles.navItem}>
          <Link href="/about" className={styles.link}>About (Static: /about)</Link>
        </li>

        <li className={styles.navItem}>
          <span className={styles.link} tabIndex={0}>Services (Nested Static)</span>
          <ul className={styles.dropdown} role="menu" aria-label="Services submenu">
            <li><Link href="/services/web" className={styles.dropdownItem}>Web Dev (/services/web)</Link></li>
            <li><Link href="/services/mobile" className={styles.dropdownItem}>Mobile (/services/mobile)</Link></li>
          </ul>
        </li>

        <li className={styles.navItem}>
          <Link href="/contact" className={styles.link}>Contact (Static: /contact)</Link>
        </li>

        <li className={styles.navItem}>
          <Link href="/blog" className={styles.link}>Blog (Dynamic: /blog/[slug])</Link>
          <ul className={styles.dropdown} role="menu" aria-label="Example blog posts">
            <li><Link href="/blog/nextjs-routing" className={styles.dropdownItem}>nextjs-routing (Dynamic)</Link></li>
            <li><Link href="/blog/react-vs-next" className={styles.dropdownItem}>react-vs-next (Dynamic)</Link></li>
          </ul>
        </li>

        <li className={styles.navItem}>
          <Link href="/docs" className={styles.link}>Docs (Catch-all: /docs/[[...slug]])</Link>
          <ul className={styles.dropdown} role="menu" aria-label="Docs examples">
            <li><Link href="/docs/intro" className={styles.dropdownItem}>/docs/intro</Link></li>
            <li><Link href="/docs/getting-started/setup" className={styles.dropdownItem}>/docs/getting-started/setup</Link></li>
          </ul>
        </li>

        <li className={styles.navItem}>
          <Link href="/dashboard" className={styles.link}>Dashboard (Grouped: /dashboard)</Link>
          <ul className={styles.dropdown} role="menu" aria-label="Dashboard submenu">
            <li><Link href="/dashboard" className={styles.dropdownItem}>Overview (/dashboard)</Link></li>
            <li><Link href="/dashboard/settings" className={styles.dropdownItem}>Settings (/dashboard/settings)</Link></li>
            <li><Link href="/dashboard/reports" className={styles.dropdownItem}>Reports (/dashboard/reports)</Link></li>
          </ul>
        </li>

      </ul>
    </nav>
  );
}
