'use client'

import { useSearchParams,useRouter } from "next/navigation";
 
export default function FlightFilterClient(){

    const params= useSearchParams()
    const router= useRouter()
    const status= params.get('status') || ''

    function setStatus(s){
        const url= new URL(window.location.href)
        if(s) url.searchParams.set('status',s)
        else url.searchParams.delete('status')
        router.push(url.pathname + url.search)

}

return (
    <div style={{margin: '8px 0'}}>
        <button onClick={()=> setStatus('')}>All</button>
        <button onClick={()=> setStatus('On Time')}>On Time</button>
         <button onClick={()=> setStatus('Delayed')}>Delayed</button>
          <div className="small">Active Filter: {status || 'none'}</div>
    </div>
)

}