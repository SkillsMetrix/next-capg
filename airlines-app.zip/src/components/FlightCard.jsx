
'use client'
import { currencyINR, flightDisplayName } from '@/models/flightModel'
import Link from 'next/link'


export default function FlightCard({flight}){
    return(
        <div className='card'>
            <h3>{flightDisplayName(flight)}</h3>
            <div className='small'>Duration: {flight.duration} Seats: {flight.seats}</div>
            <div style={{marginTop: 8}}>
                <strong>{currencyINR(flight.price)}</strong>
                <span style={{marginLeft: 12}} className='small'>Status: {flight.status}</span>
            </div>
            <div style={{marginTop: 12}}>

                <Link href={`/flights/${flight.id}`}>View Details</Link>

                
            </div>

        </div>
    )
}