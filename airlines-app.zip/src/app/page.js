import Link from "next/link";

export default function Home() {
  return (
    <div>
      <h2>Welcome to Airlines Bookings</h2>
      <p className="small">Flight Booking app</p>
      <div style={{ marginTop: 20 }}>
        <Link href="/flights">Browse Flights</Link>
      </div>
    </div>
  );
}
