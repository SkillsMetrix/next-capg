


export default async function FlightDetails({params}){
    const {id} = params

    return(
        <div>
            {id}
        </div>
    )
}