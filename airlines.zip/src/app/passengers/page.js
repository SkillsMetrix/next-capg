import Link from "next/link";

export default function Passengers() {
  return (
    <div>
      <h2>Welcome to Passengers Bookings</h2>
     
       
    </div>
  );
}
