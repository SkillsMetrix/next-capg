const ApiError = require('../errors/ApiError');
const logger = require('../logger');

function errorHandler(err, req, res, next) {
  if (req && req.log) {
    req.log.error({ err }, 'Unhandled error');
  } else {
    logger.error({ err }, 'Unhandled error');
  }

  if (err instanceof ApiError) {
    return res.status(err.status).json({
      status: 'error',
      message: err.message,
      code: err.code,
      details: err.details || null
    });
  }

  res.status(500).json({ status: 'error', message: 'Internal Server Error', code: 'INTERNAL_ERROR' });
}

module.exports = errorHandler;
