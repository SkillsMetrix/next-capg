import Image from "next/image";
import styles from "./page.module.css";

import MainApp from "./components/MainApp";
import RestApp from "./components/RestApp";

export default function Home() {
  return (
    <div className={styles.page}>
  
      <MainApp/>
       
    </div>
  );
}
