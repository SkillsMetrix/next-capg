"use client";
import { useState } from "react";
import styles from "../styles/App.module.css";
function AddUser({ onAdd }) {
  const [userName, setUserName] = useState("");
  const [email, setEmail] = useState("");
  const [city, setCity] = useState("");

const handleSubmit = (e) => {
  e.preventDefault();
  if (!userName.trim() || !email.trim() || city.trim())
    return alert("All fields are Mandatory");

  onAdd({ userName: userName.trim(), email: email.trim(), city: city.trim() });
};
return (
    
      <form onSubmit={handleSubmit} className={styles.form}>
        <h3>Add User</h3>
        <input placeholder="Enter UserName" value={userName} onChange={e => setUserName(e.target.value)}
        className={styles.input}
        />&nbsp;
         <input placeholder="Enter Email" value={email} onChange={e => setEmail(e.target.value)}
        className={styles.input}
        />&nbsp;
         <input placeholder="Enter City" value={city} onChange={e => setCity(e.target.value)}
        className={styles.input}
        />&nbsp;
        <div>
            <button className="{styles.button}">Add User</button>
        </div>
      </form>
 
  );
}
export default AddUser;
