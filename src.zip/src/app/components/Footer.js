"use client"

function Footer(props){

    return(

        <div>
            <p>{props.fn}</p>
        </div>
    )
}
export default Footer