'use client'
import styles from '../styles/App.module.css'
import UserItem from './User'

export default function UserList({users,onDelete}){
        if(!users.length) return <div className={styles.empty}>No Users saved yet</div>
    return (
       
            <div>
                <h3>Users</h3>
                <div className={styles.list}> 
                {users.map(u => (
                    <UserItem user={u} key={u.id} onDelete={onDelete}/>
                ))}
                </div>
               
            </div>
            

        
    )
}