

export default async function RestApp(){
    const data= await fetch('https://jsonplaceholder.typicode.com/users').then(res=> res.json)
    return <pre>{JSON.stringify(data,null,2)}</pre>
}