
"use client"
import styles from "../styles/App.module.css";
function Header(props){

    return(

        <div>
          <h1 className={styles.title}></h1>
        </div>
    )
}
export default Header