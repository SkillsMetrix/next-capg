"use client";
import { Component } from "react";
import Header from "./Header";
import Footer from "./Footer";
import AddUser from "./AddUser";
import styles from "../styles/App.module.css";
import { useUsers } from "../hooks/useUsers";
import UserList from "./Users";

function MainApp() {
  const { users, addUser,deleteUser } = useUsers();

   
  const headerMessage = " NextJS User CRUD App";
  const footerMessage = "User CopyRight Message";

  return (
    <div>
        <Header hm={headerMessage}/>

    
    <main className={styles.container}>
      

      <div className={styles.grid}>
        <div className={styles.card}>
          <AddUser onAdd={addUser}/>
          </div>
          <div className={styles.card}>
            <UserList users={users} onDelete={deleteUser}/>
          </div>
          </div>

      <Footer fn={footerMessage}/>
    </main>
    </div>
  );
}

export default MainApp;
