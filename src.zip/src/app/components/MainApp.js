"use client";
import { Component } from "react";
import Header from "./Header";
import Footer from "./Footer";
import AddUser from "./AddUser";
import styles from "../styles/App.module.css";
import { useUsers } from "../hooks/useUsers";

function MainApp() {
  const { users, addUser } = useUsers();

  const handleSaveEdit = (id, patch) => {};
  const headerMessage = " NextJS User CRUD App";
  const footerMessage = "User CopyRight Message";
  return (
    <main className={styles.container}>
      <Header hm={headerMessage}/>

      <div className={styles.grid}>
        <div className={styles.card}>
            <AddUser />
        </div>

      </div>

      <Footer fn={footerMessage}/>
    </main>
  );
}

export default MainApp;
