
export default function FlightDetailsLoading(){
    return <div className="card">Loading flight Details.....!</div>
}