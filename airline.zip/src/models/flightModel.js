export function flightDisplayName(flight){
    return `${flight.code} - ${flight.from} -> ${flight.to}`
}

export function currencyINR(amount){
    return `₹${amount}`
}