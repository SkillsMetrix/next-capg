export function passengerDisplay(p){
    return `${p.name} (${p.age})`
}