
import Link from "next/link";
import styles from './Navigation.module.css'
export default function Navigation(){
    return(

      <nav className={styles.navBar} aria-label="Main navigation">
      <ul className={styles.navList}>
        <li className={styles.navItem}>
        <Link href="/" className={styles.link}>Home</Link> | {" "}
        </li>

         <li className={styles.navItem}>
        <Link href="/flights" pr className={styles.link}>Flights</Link> | {" "}
        </li>

   <li className={styles.navItem}>
        <Link href="/passengers" className={styles.link}>Passengers</Link> | {" "}
        </li>
  <li className={styles.navItem}>
        <Link href="/passengers/add" className={styles.link}>Add Passengers</Link> 
        </li>

      
      </ul>
</nav>
    )
}