import Link from "next/link";
import dynamic from "next/dynamic";
import { fetchFlights } from "@/lib/api";
import { Suspense } from "react";

const FlightCard= dynamic(()=>import('../../components/FlightCard'),{
  loading: () => <div className="card">Loading card.....!</div>
})
export default async function FlightsPage({searchParams}) {

  const resolved= await searchParams;
  let status= resolved?.status ?? null
  if (Array.isArray(status))status = status[0]
  if( status === '')status= null
  
  let flights = await fetchFlights()
  if(status) flights = flights.filter(f => String(f.status).toLowerCase() === String(status).toLowerCase())
  return (
    <div>
      <div className="grid">
        {flights.map(f => (
          <Suspense key={f.id} fallback={<div className="card">Loading...!</div>}>
            <FlightCard flight={f}/>
          </Suspense>
        ))}
      </div>
      </div>
  );
}
