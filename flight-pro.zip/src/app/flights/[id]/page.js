import PassengerCard from "@/components/PassengerCard"
import { fetchFlightByID, fetchPassengersByFlightID } from "@/lib/api"



export default async function FlightDetails({params}){
    const {id} = params
    const flight= await fetchFlightByID(id)
    const passengers= await fetchPassengersByFlightID(id)


    return(
        <div>
            <h2>{flight.code} :Details</h2>
            <div className="card">
                <div><strong>{flight.from} - {flight.to}</strong></div>
                <div className="small">Duration: {flight.duration} * Seats: {flight.seats}</div>
                 <div className="small">Price: ₹{flight.price} * Status: {flight.status}</div>
            </div>
            <h3>Passengers in this flight</h3>
            <div className="grid">
                {passengers.length
                ? passengers.map(p => <PassengerCard key={p.id} passenger={p} />)
                : <div className="card">No Passengers yet</div>
                
                }
            </div>

        </div>
    )
}