
'use client'
export default function FlightDetailsError({error}){
    return (
        <div className="card">
            <h3>Error Loading Flight Details</h3>
            <pre>{String(error)}</pre>
        </div>
    )
}