
'use client'
export default function PassengersDetailsError({error}){
    return (
        <div className="card">
            <h3>Error Loading Passengers Details</h3>
            <pre>{String(error)}</pre>
        </div>
    )
}