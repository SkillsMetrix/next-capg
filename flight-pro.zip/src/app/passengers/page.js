import PassengerCard from "@/components/PassengerCard";
import { fetchPassengers } from "@/lib/api";


export default async function Passengers() {
  const passengers= await fetchPassengers()

  return (
    <div>
  <h2>Passengers Details</h2>   
  <div className="grid">
    {passengers.map(p => <PassengerCard key={p.id} passenger={p}/>)}
    </div> 
     
       
    </div>
  );
}
