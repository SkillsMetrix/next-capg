import AddPassengerForm from "@/components/AddPassengerForm";
import Link from "next/link";

export default function Flight() {
  return (
    <div>
      <h2>Welcome to Add Passengers</h2>

      <AddPassengerForm/>
       
    </div>
  );
}
