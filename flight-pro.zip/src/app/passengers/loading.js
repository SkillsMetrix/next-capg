
export default function PassengersDetailsLoading(){
    return <div className="card">Loading Passengers Details.....!</div>
}