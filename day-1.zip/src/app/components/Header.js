
"use client"
import styles from "../styles/App.module.css";
function Header(props){

    return(

        <div>
            
          <h1 className={styles.title}>{props.hm}</h1>
        </div>
    )
}
export default Header