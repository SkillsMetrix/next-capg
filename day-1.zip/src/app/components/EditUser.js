'use client'

import React, { useState } from 'react'
import styles from '../styles/App.module.css'

export default function EditUser({ user,onSave,onCancel }) {
  const [username, setUsername] = useState(user.username)
  const [email, setEmail] = useState(user.email)
  const [city, setCity] = useState(user.city)

   
  const handleSave = (e) => {
    e.preventDefault()
    if (!username.trim() || !email.trim() || !city.trim()) return alert('All fields required')
    onSave(user.id,{ username: username.trim(), email: email.trim(), city: city.trim() })
   }
    return (
    <form onSubmit={handleSave} className={styles.formInline}>
     
      <input value={username} onChange={e => setUsername(e.target.value)} className={styles.smallInput} />
      <input value={email} onChange={e => setEmail(e.target.value)} className={styles.smallInput} />
      <input value={city} onChange={e => setCity(e.target.value)} className={styles.smallInput} />
      <div className={styles.controls}>
        <button type="submit" className={styles.buttonSmall}>Update</button>
        <button type="button" onClick={onCancel} className={styles.secondarySmall}>Cancel</button>
         
      </div>
    </form>
  )
}
