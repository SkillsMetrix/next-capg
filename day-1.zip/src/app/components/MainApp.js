"use client";
import { Component, useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import AddUser from "./AddUser";
import styles from "../styles/App.module.css";
import { useUsers } from "../hooks/useUsers";
import UserList from "./Users";
import EditUser from "./EditUser";

function MainApp() {
  const { users, addUser,deleteUser ,clearAll,updateUser} = useUsers();
  const [editing,setEditing]= useState(null)

  const handleRequestEdit=(user) => setEditing(user)
  const handleCancelEdit =() => setEditing(null)
  const handleSaveEdit=(id,patch) => {
    updateUser(id,patch)
    setEditing(null)
  }

  const headerMessage = " NextJS User CRUD App";
  const footerMessage = "User CopyRight Message";

  return (
    <div>
    <Header hm={headerMessage}/>
    <main className={styles.container}>
      <div className={styles.grid}>
        <div className={styles.card}>
          <AddUser onAdd={addUser}/>
          </div>

          <div className={styles.card}>
          {editing ? (
            <div>
              <h3>Edit User</h3>
              <EditUser user={editing} onSave={handleSaveEdit} onCancel={handleCancelEdit} />
              </div>
          ): (
               <UserList users={users} onRequestEdit={handleRequestEdit} onDelete={deleteUser} onClearAll={clearAll}/>
          )
        }
           
          </div>
          </div>

      <Footer fn={footerMessage}/>
    </main>
    </div>
  );
}

export default MainApp;
