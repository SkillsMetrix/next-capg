'use client'

import React, { useState } from 'react'
import styles from '../styles/App.module.css'

export default function UserForm({ onAdd }) {
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [city, setCity] = useState('')

  const reset=()=>{
    setUsername('')
    setEmail('')
    setCity('')

  }

   
  const handleSubmit = (e) => {
    e.preventDefault()
    if (!username.trim() || !email.trim() || !city.trim()) return alert('All fields required')

    onAdd({ username: username.trim(), email: email.trim(), city: city.trim() })
    reset()
     
  }

  return (
    <form onSubmit={handleSubmit} className={styles.form}>
      <h3>Add User</h3>
      <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} className={styles.input} />
      <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} className={styles.input} />
      <input placeholder="City" value={city} onChange={e => setCity(e.target.value)} className={styles.input} />
      <div className={styles.controls}>
        <button type="submit" className={styles.button}>Add</button>
        <button type="button" onClick={reset} className={styles.button}>Reset</button>
         
      </div>
    </form>
  )
}
