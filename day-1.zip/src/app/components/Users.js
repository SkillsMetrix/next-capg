'use client'
import styles from '../styles/App.module.css'
import UserItem from './User'

export default function UserList({users,onDelete,onClearAll,onRequestEdit}){
        if(!users.length) return <div className={styles.empty}>No Users saved yet</div>
    return (
       
            <div>
                <h3>Users</h3>
                <div className={styles.list}> 
                {users.map(u => (
                    <UserItem user={u} key={u.id} onDelete={onDelete} onRequestEdit={onRequestEdit}/>
                ))}
                </div>
               <div style={{marginTop: 10}}>
                <button onClick={onClearAll} className={styles.danger}>Clear All</button>
               </div>
            </div>
            

        
    )
}