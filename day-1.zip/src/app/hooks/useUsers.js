'use client'

import { useEffect, useState } from "react"
import { readFromStorage, writeToStorage } from "../lib/storage"


export function useUsers(){
    const [users,setUsers]= useState([])

    useEffect(()=>{
        setUsers(readFromStorage)
    },[])

    useEffect(()=>{
        writeToStorage(users)
    },[users])

    const deleteUser=(id)=>{
        setUsers(prev => prev.filter(u => u.id !==id))
    }
    const updateUser=(id,patch)=>{
         setUsers(prev => prev.map(u => (u.id === id ? {...u,...patch} : u)))
    }
    const addUser=(user)=>{
        setUsers(prev => [...prev,{...user,id: Date.now().toString()}])
    }
    const clearAll= () => setUsers([])
    
    return {users,addUser,deleteUser,clearAll,updateUser}
}