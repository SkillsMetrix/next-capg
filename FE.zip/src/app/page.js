import Image from "next/image";

export default function Home() {
  return (
    <div className="space-y-3">
        <h3 className="text-2xl font-semibold">Welcome to FullStack</h3>
    </div>
  )
}