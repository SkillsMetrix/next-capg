

import React from 'react';

function AddUser(props) {
    return (
        <div className='space-y-4'>
            <h2 className='text-x1 font-medium'>Add User</h2>
        </div>
    );
}

export default AddUser;