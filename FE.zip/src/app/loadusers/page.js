

import React from 'react';

function LoadUsers(props) {
    return (
        <div className='space-y-4'>
            <h2 className='text-x1 font-medium'>Load User</h2>
        </div>
    );
}

export default LoadUsers;