
'use client'

import Link from "next/link"
import { usePathname } from "next/navigation"

export default function NavBar(){
    const pathName= usePathname()
    const linkClass= (p) => `mr-6 text-sm ${pathName === p ? 'font-semibold underline' : 'text-blue-600 hover:underline'}`
    return (
        <nav className="bg-white shadow-sm">
            <div className="max-w-4xl mx-auto px-4 py-3 flex items-center">
                <div className="flex-1"><Link href="/" className="text-lg font-bold text-gray-800">User App</Link></div>
                <div>
                    <Link href="/" className={linkClass('/')}>Home</Link>
                     <Link href="/loadusers" className={linkClass('/loadusers')}>Load Users</Link>
                     <Link href="/adduser" className={linkClass('/adduser')}>Add User</Link>
                </div>
            </div>
        </nav>
    )
}