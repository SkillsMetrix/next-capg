
class APIError extends Error{

    constructor(status=500,message='internal Server Error',code="Internal error", details= null){
        super(message)
        this.status=status
        this.code=code
        this.details=details
        Error.captureStackTrace(this,this.constructor)
    }
}
module.exports= APIError