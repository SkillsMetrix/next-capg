const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const bodyParser = require('body-parser');
const ApiError = require('./errors/ApiError');
const errorHandler = require('./middleware/errorHandler');
const pinoHttp = require('pino-http');
const logger = require('./logger');
const app = express();
app.use(pinoHttp({ logger }));
app.use(cors());
app.use(bodyParser.json());

const JSON_SERVER = process.env.JSON_SERVER_URL || 'http://localhost:4000';

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

app.get('/users', wrap(async (req, res) => {
  req.log.info('GET /users requested');
  const r = await fetch(`${JSON_SERVER}/users`);
  if (!r.ok) {
    const text = await r.text();
    req.log.error({ upstream: text }, 'Upstream json-server error');
    throw new ApiError(502, 'Upstream json-server error', 'UPSTREAM_ERROR', { upstreamText: text });
  }
  const users = await r.json();
  res.json(users);
}));
app.use(errorHandler)
app.listen(3004,()=>{
    console.log('Server is running ')
})