class ApiError extends Error {
  constructor(status = 500, message = 'Internal Server Error', code = 'INTERNAL_ERROR', details = null) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
    Error.captureStackTrace(this, this.constructor);
  }
}
module.exports = ApiError;
