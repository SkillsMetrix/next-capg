const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const bodyParser = require('body-parser');
const ApiError = require('./errors/ApiError');
const errorHandler = require('./middleware/errorHandler');
const pinoHttp = require('pino-http');
const logger = require('./logger');

const app = express();


app.use(pinoHttp({ logger }));

app.use(cors());
app.use(bodyParser.json());

const JSON_SERVER = process.env.JSON_SERVER_URL || 'http://localhost:4000';

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

app.get('/users', wrap(async (req, res) => {
  req.log.info('GET /users requested');
  const r = await fetch(`${JSON_SERVER}/users`);
  if (!r.ok) {
    const text = await r.text();
    req.log.error({ upstream: text }, 'Upstream json-server error');
    throw new ApiError(502, 'Upstream json-server error', 'UPSTREAM_ERROR', { upstreamText: text });
  }
  const users = await r.json();
  res.json(users);
}));

 app.post('/users', wrap(async (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) {
    req.log.warn({ body: req.body }, 'Validation failed on POST /users');
    throw new ApiError(400, 'name and email required', 'VALIDATION_ERROR', { fields: ['name','email'] });
  }

  const r = await fetch(`${JSON_SERVER}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email })
  });

  const text = await r.text();
  if (!r.ok) {
    req.log.error({ upstream: text }, 'Upstream create failed');
    throw new ApiError(502, 'Upstream create failed', 'UPSTREAM_ERROR', { upstreamText: text });
  }

  const created = JSON.parse(text);
  res.status(201).json(created);
})); 

// error handler
app.use(errorHandler);

const PORT = process.env.PORT || 3001;
app.listen(3001, () => logger.info(`Express API running → http://localhost:${PORT}`));
