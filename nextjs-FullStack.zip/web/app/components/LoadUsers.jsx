'use client';
import { useEffect } from 'react';
import { useAppDispatch, useAppSelector } from '../../redux/hooks';
import { loadUsersRequest, setUsers } from '../../redux/users/usersSlice';

export default function LoadUsers({ initialUsers = [] }) {
  const dispatch = useAppDispatch();
  const users = useAppSelector(s => s.users.items);
  const loading = useAppSelector(s => s.users.loading);
  const error = useAppSelector(s => s.users.error);

  useEffect(() => {
    if (initialUsers && initialUsers.length) {
      dispatch(setUsers(initialUsers));
    } else {
      dispatch(loadUsersRequest());
    }
  }, [initialUsers, dispatch]);

  return (
    <div className="bg-white shadow-sm rounded p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-medium">Users</h3>
        <div>
          <button onClick={() => dispatch(loadUsersRequest())} disabled={loading} className="px-3 py-1 text-sm rounded border">
            {loading ? 'Loading...' : 'Reload'}
          </button>
        </div>
      </div>

      {error && <div className="mb-3 p-3 bg-red-50 text-red-700 rounded">{error}</div>}

      <ul className="space-y-2">
        {users.map(u => (
          <li key={u.id} className="p-3 border rounded flex items-center justify-between">
            <div>
              <div className="font-semibold">{u.name}</div>
              <div className="text-sm text-gray-500">{u.email}</div>
            </div>
            <div className="text-sm text-gray-400">#{u.id}</div>
          </li>
        ))}
        {users.length === 0 && !loading && <li className="text-sm text-gray-500">No users found.</li>}
      </ul>
    </div>
  );
}
