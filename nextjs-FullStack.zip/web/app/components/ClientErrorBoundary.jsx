'use client';
import React from 'react';

export default class ClientErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false, error: null }; }
  static getDerivedStateFromError(error) { return { hasError: true, error }; }
  componentDidCatch(error, info) {
    console.error('Client component error:', error, info);
    try {
      fetch('/api/logs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ level: 'error', message: String(error?.message || error), meta: { stack: error?.stack, info } })
      });
    } catch (e) { /* swallow */ }
  }
  reset = () => this.setState({ hasError: false, error: null });
  render() {
    if (this.state.hasError) {
      return (
        <div className="p-4 bg-red-50 border rounded">
          <div className="text-red-700 font-semibold">Something went wrong in this component.</div>
          <div className="mt-2 text-sm text-gray-700">{process.env.NODE_ENV === 'development' ? String(this.state.error) : 'Please refresh.'}</div>
          <div className="mt-3"><button onClick={this.reset} className="px-3 py-1 rounded bg-blue-600 text-white">Try again</button></div>
        </div>
      );
    }
    return this.props.children;
  }
}
