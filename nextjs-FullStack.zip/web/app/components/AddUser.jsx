'use client';
import { useState } from 'react';
import { useAppDispatch, useAppSelector } from '../../redux/hooks';
import { addUserRequest } from '../../redux/users/usersSlice';
import { useRouter } from 'next/navigation';

export default function AddUser() {
  const dispatch = useAppDispatch();
  const loading = useAppSelector(s => s.users.loading);
  const error = useAppSelector(s => s.users.error);
  const router = useRouter();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleAdd = (e) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return alert('Enter name and email');

    dispatch(addUserRequest({ name: name.trim(), email: email.trim() }));
    setName(''); setEmail('');
    setTimeout(() => router.push('/loadusers'), 300);
  };

  return (
    <form onSubmit={handleAdd} className="bg-white shadow-sm rounded p-4 space-y-3">
      {error && <div className="p-2 bg-red-50 text-red-700 rounded">{error}</div>}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <input className="border rounded px-3 py-2" placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
        <input className="border rounded px-3 py-2" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
      </div>

      <div className="flex items-center justify-between">
        <div className="text-sm text-gray-500">Add a new user (via Next API → Express → json-server).</div>
        <button type="submit" disabled={loading} className="px-4 py-2 rounded bg-blue-600 text-white">
          {loading ? 'Saving...' : 'Add User'}
        </button>
      </div>
    </form>
  );
}
