'use client';
import React from 'react';
import { Provider } from 'react-redux';
import { makeStore } from '../../redux/store';

export default function Providers({ children }) {
  const store = React.useMemo(() => makeStore(), []);
  return <Provider store={store}>{children}</Provider>;
}
