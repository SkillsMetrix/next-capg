'use client';
import { useEffect } from 'react';

export default function GlobalError({ error, reset }) {
  useEffect(() => { console.error('App-level error:', error); }, [error]);

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gray-50">
      <div className="bg-white p-6 rounded shadow max-w-lg w-full space-y-4">
        <h2 className="text-xl font-semibold">Something went wrong</h2>
        <p className="text-sm text-gray-600">An unexpected error occurred while rendering.</p>
        <div className="text-sm text-red-600 break-words">{process.env.NODE_ENV === 'development' ? String(error?.message) : 'Please try again later.'}</div>
        <div className="flex gap-2">
          <button onClick={() => reset()} className="px-4 py-2 rounded bg-blue-600 text-white">Try again</button>
          <button onClick={() => (window.location.href = '/')} className="px-4 py-2 rounded border">Home</button>
        </div>
      </div>
    </div>
  );
}
