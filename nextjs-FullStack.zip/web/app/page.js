export default function Home() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">NextJS Full Stack Application</h2>
      <p className="text-sm text-gray-600">Use the navbar to load or add users.</p>
    </div>
  );
}
