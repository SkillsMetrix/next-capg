import ClientErrorBoundary from '../components/ClientErrorBoundary';
import LoadUsers from '../components/LoadUsers';

const API = process.env.API_URL || 'http://localhost:3001';

export default async function Page() {
  const res = await fetch(`${API}/users`, { cache: 'no-store' });
  if (!res.ok) throw new Error('Failed to fetch users on server');
  const users = await res.json();

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-medium">Load Users</h2>
      <ClientErrorBoundary>
        <LoadUsers initialUsers={users} />
      </ClientErrorBoundary>
    </div>
  );
}
