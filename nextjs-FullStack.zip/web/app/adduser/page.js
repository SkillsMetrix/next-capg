import AddUser from '../components/AddUser';

export default function Page() {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-medium">Add User</h2>
      <AddUser />
    </div>
  );
}
