import Navbar from './components/Navbar';
import '../styles/globals.css';
import Providers from './components/Providers';

export const metadata = { title: 'Next + Express + Pino Demo' };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <Providers>
          <main className="max-w-3xl mx-auto p-6">{children}</main>
        </Providers>
      </body>
    </html>
  );
}
