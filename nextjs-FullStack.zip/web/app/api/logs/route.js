import logger from '../../../utils/logger';

export async function POST(req) {
  try {
    const payload = await req.json();
    const { level = 'error', message = 'client error', meta = {} } = payload;
    if (logger[level]) logger[level]({ meta, source: 'client' }, message);
    else logger.info({ meta, source: 'client' }, message);
    return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    console.error('Failed to handle client log', err);
    return new Response(JSON.stringify({ ok: false }), { status: 500, headers: { 'Content-Type': 'application/json' } });
  }
}
