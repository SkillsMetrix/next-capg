import logger from '../../../utils/logger';

const UPSTREAM = process.env.API_URL || 'http://localhost:3001';

async function proxyFetch(path, opts = {}) {
  const url = `${UPSTREAM}${path}`;
  const res = await fetch(url, opts);
  const ct = res.headers.get('content-type') || '';
  const text = await res.text();
  let data = null;
  try { if (ct.includes('application/json')) data = JSON.parse(text); else data = text; } catch { data = text; }

  if (!res.ok) {
    const msg = data?.message || data || `Upstream error: ${res.status}`;
    const payload = { status: 'error', message: msg, code: 'UPSTREAM_ERROR', details: data };
    logger.error({ payload, url }, 'Upstream error on proxyFetch');
    return new Response(JSON.stringify(payload), { status: 502, headers: { 'Content-Type': 'application/json' } });
  }

  logger.info({ url }, 'Proxy fetch success');
  return new Response(JSON.stringify(data), { status: res.status, headers: { 'Content-Type': 'application/json' } });
}

export async function GET() {
  try {
    return await proxyFetch('/users');
  } catch (err) {
    logger.error({ err }, 'API GET /api/users error');
    return new Response(JSON.stringify({ status:'error', message:'Internal server error' }), { status: 500, headers: { 'Content-Type': 'application/json' } });
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    if (!body || !body.name || !body.email) {
      return new Response(JSON.stringify({ status:'error', message:'name and email required', code:'VALIDATION_ERROR' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
    }
    return await proxyFetch('/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  } catch (err) {
    logger.error({ err }, 'API POST /api/users error');
    return new Response(JSON.stringify({ status:'error', message:'Internal server error' }), { status: 500, headers: { 'Content-Type': 'application/json' } });
  }
}
