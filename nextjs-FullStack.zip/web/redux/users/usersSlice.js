import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  items: [],
  loading: false,
  error: null,
};

const usersSlice = createSlice({
  name: 'users',
  initialState,
  reducers: {
    loadUsersRequest(state) { state.loading = true; state.error = null; },
    addUserRequest(state) { state.loading = true; state.error = null; },
    loadUsersSuccess(state, action) { state.items = action.payload; state.loading = false; },
    addUserSuccess(state) { state.loading = false; },
    operationFailure(state, action) { state.loading = false; state.error = action.payload; },
    setUsers(state, action) { state.items = action.payload; state.error = null; }
  },
});

export const { loadUsersRequest, addUserRequest, loadUsersSuccess, addUserSuccess, operationFailure, setUsers } = usersSlice.actions;
export default usersSlice.reducer;
