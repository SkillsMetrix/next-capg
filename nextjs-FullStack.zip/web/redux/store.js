import { configureStore } from '@reduxjs/toolkit';
import createSagaMiddleware from 'redux-saga';
import usersReducer from './users/usersSlice';
import rootSaga from './rootSaga';

export function makeStore(preloadedState) {
  const sagaMiddleware = createSagaMiddleware();
  const store = configureStore({
    reducer: { users: usersReducer },
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware({ thunk: false, serializableCheck: false }).concat(sagaMiddleware),
    preloadedState,
  });
  sagaMiddleware.run(rootSaga);
  return store;
}
